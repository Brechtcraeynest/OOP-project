﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using test_list_opslaan;

namespace ScoreKeeper
{
    public partial class MainWindow : Window
    {
        private List<ScoreOpslaan> scores = new List<ScoreOpslaan>();

        public MainWindow()
        {
            InitializeComponent();
            SchrijfTxtInList();
        }

        private void SchrijfTxtInList()
        {
            try
            {
                string[] lines = File.ReadAllLines("scores.txt");
                scores = new List<ScoreOpslaan>();
                foreach (string line in lines)
                {
                    string[] parts = line.Split(':');
                    if (parts.Length == 2 && int.TryParse(parts[1], out int score))
                    {
                        ScoreOpslaan ScoreOpslaan = new ScoreOpslaan(parts[0].Trim(), score);
                        scores.Add(ScoreOpslaan);
                    }
                }
                scores = scores.OrderByDescending(x => x.Score).ToList(); // Sorteer scores 
                UpdateList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Fout bij laden van scores: {ex.Message}");
            }
        }

        private void SlaOpInTxt()
        {
            try
            {
                List<string> lines = new List<string>();
                foreach (ScoreOpslaan ScoreOpslaan in scores)
                {
                    string line = $"{ScoreOpslaan.Name}: {ScoreOpslaan.Score}";
                    lines.Add(line);
                }
                File.WriteAllLines("scores.txt", lines);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Fout bij opslaan van scores: {ex.Message}");
            }
        }

        private void UpdateList()
        {
            scoresList.Items.Clear();
            foreach (ScoreOpslaan scoreOpslaan in scores)
            {
                scoresList.Items.Add($"{scoreOpslaan.Name}: {scoreOpslaan.Score}");
            }
        }

        private void btnToevoegen_Click(object sender, RoutedEventArgs e)
        {
            string name = txtbxNaam.Text;
            int score = 0;
            if (!string.IsNullOrEmpty(name) && int.TryParse(txtbxScore.Text, out score))
            {
                // Create a new ScoreOpslaan object and add it to the scores list
                ScoreOpslaan scoreOpslaan = new ScoreOpslaan(name, score);
                scores.Add(scoreOpslaan);

                // Sort scores by score in descending order
                scores = scores.OrderByDescending(x => x.Score).ToList();

                // Update the scores list on the UI
                UpdateList();

                // Save scores to file
                SlaOpInTxt();

                // Clear text boxes
                txtbxNaam.Clear();
                txtbxScore.Clear();
            }
            else
            {
                MessageBox.Show("Please enter a valid name and score.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
    
}
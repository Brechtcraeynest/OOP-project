﻿using System;
using System.IO;

namespace ScoreOpslaan
{
    class Program
    {
        static void Main(string[] args)
        {
            // Definieer het bestandspad
            string filePath = "scorefile.txt";

            // Lees de inhoud van het bestand
            string fileContents = File.ReadAllText(filePath);

            // Vind de waarden van "Score" en "Naam"
            string scoreValue = GetValueFromLine("Score:", fileContents);
            string naamValue = GetValueFromLine("Naam:", fileContents);

            // Geef de huidige waarden weer
            Console.WriteLine("Huidige score: " + scoreValue);
            Console.WriteLine("Huidige naam: " + naamValue);

            // Wijzig de waarden
            scoreValue = "100";
            naamValue = "Brecht";

            // Werk de inhoud van het bestand bij
            fileContents = SetValueInLine("Score:", scoreValue, fileContents);
            fileContents = SetValueInLine("Naam:", naamValue, fileContents);

            // Schrijf de bijgewerkte inhoud terug naar het bestand
            File.WriteAllText(filePath, fileContents);

            // Geef de nieuwe waarden weer
            Console.WriteLine("Nieuwe score: " + scoreValue);
            Console.WriteLine("Nieuwe naam: " + naamValue);
        }

        static string GetValueFromLine(string key, string fileContents)
        {
            int startIndex = fileContents.IndexOf(key) + key.Length;
            int endIndex = fileContents.IndexOf("\n", startIndex);

            if (endIndex == -1)
            {
                endIndex = fileContents.Length;
            }

            return fileContents.Substring(startIndex, endIndex - startIndex).Trim();
        }

        static string SetValueInLine(string key, string value, string fileContents)
        {
            int startIndex = fileContents.IndexOf(key) + key.Length;
            int endIndex = fileContents.IndexOf("\n", startIndex);

            if (endIndex == -1)
            {
                endIndex = fileContents.Length;
            }

            string line = fileContents.Substring(startIndex, endIndex - startIndex).Trim();
            string newLine = key + " " + value;

            return fileContents.Replace(line, newLine);
        }
    }
}

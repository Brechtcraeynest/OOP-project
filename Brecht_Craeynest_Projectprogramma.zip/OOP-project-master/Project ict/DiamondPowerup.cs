﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_ict
{
    internal class DiamondPowerup : Powerup
    {
        public override string Toevoegen()
        {
            
            count += 2;
            return count.ToString();
        }

        public override string Resetten()
        {
            // Roep de basisimplementatie van Resetten aan om de teller op nul te zetten
            base.Resetten();
            return count.ToString();
        }

        public override string Tonen()
        {
            // Roep de basisimplementatie van Tonen aan om het totaal aantal power-ups te retourneren
            return base.Tonen();
        }
    }
}
